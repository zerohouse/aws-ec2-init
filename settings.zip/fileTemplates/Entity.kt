#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")

import javax.persistence.Entity
import com.zerohouse.tables.IdTable

@Entity
class ${NAME} : IdTable() {
}