#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")

#set($name = ${NAME})
#set($smallerName = ${name.substring(0,1).toLowerCase()}+${name.substring(1)})

import org.springframework.web.bind.annotation.*
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest

@RestController
@RequestMapping("/${smallerName}")
class ${NAME}Controller(val ${smallerName}Service: ${NAME}Service) {

    @GetMapping("/list")
    fun get${NAME}List(@RequestParam(defaultValue = "0") page: Int, @RequestParam(defaultValue = "10") size: Int): Page<${NAME}> {
        return ${smallerName}Service.get${NAME}List(PageRequest.of(page, size))
    }

    @GetMapping
    fun get${NAME}(@RequestParam id: Long): ${NAME} {
        return ${smallerName}Service.get${NAME}(id)
    }

    @PostMapping
    fun save${NAME}(@RequestBody ${smallerName}: ${NAME}): ${NAME} {
        return ${smallerName}Service.save${NAME}(${smallerName})
    }
    
    @DeleteMapping
    fun delete${NAME}(@RequestParam id: Long) {
        return ${smallerName}Service.delete${NAME}(id)
    }
}
