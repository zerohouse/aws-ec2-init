#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")

import org.springframework.data.repository.CrudRepository
import org.springframework.stereotype.Repository

@Repository
interface ${NAME}Repository : CrudRepository<${NAME}, Long> 